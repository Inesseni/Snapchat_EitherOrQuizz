/*
// Script.js

// Version: 1.0.0

// Event: On Awake

QUIZZ CONTROLLER!
This script enables you to easily build a dynamic either-or quizz in the object hierarchy.
It iterates through the child objects of the "Choices Tree" Scene object so it can 
be expanded just by adding two(!) children to a Scene Object of the tree.

IMPORTANT:
All new children/choices need a "ScreenImage" Component with a matching texture assigned and a "Text" Component describing the choice.
*/

//@input SceneObject rootObj {"hint": "Parent of the first choice"}
var root = script.rootObj;
var currentRoot = root;
var choicesPath = "";
var inputAllowed = true;

 


/*
We check if the current Scene Object has 2 children / options.
If yes, we get the textures and texts from the children/choices and set it as the final screenImages and texts.
If Not, we either have an issue with the tree (more or less than 2 options) or the game is finished !
*/
//@ui {"widget":"label"}
//@input Component.Image leftChoiceImg {"label":"Left Image"}
//@input Component.Text leftChoiceText {"label":"Left Text"}
//@input Component.Image rightChoiceImg {"label":"Right Image"}
//@input Component.Text rightChoiceText {"label":"Right Text"}
function progressQuizz(withThisObj){
    var moreChoices = checkForMoreChoices(withThisObj); //checking for a new choice here
    
    if(moreChoices == true){
        script.maskTweenObj.getComponent("Component.ScreenTransform").anchors.right = 0;
        script.leftChoiceImg.mainPass.baseTex = withThisObj.getChild(0).getComponent("Component.Image").mainPass.baseTex;
        script.rightChoiceImg.mainPass.baseTex = withThisObj.getChild(1).getComponent("Component.Image").mainPass.baseTex;
        script.leftChoiceText.text = withThisObj.getChild(0).getComponent("Component.Text").text;
        script.rightChoiceText.text = withThisObj.getChild(1).getComponent("Component.Text").text;
    }else if(moreChoices == false){
        print("Quizz finished!")
        triggerEndResult();
        inputAllowed = false;
    }
}
progressQuizz(root);

function checkForMoreChoices(ofThisObj){
    var childrenLength = ofThisObj.getChildrenCount();
    if( childrenLength == 0){
        return false;  //in this case, we reached the end of the choices tree. The quizz is finished!
    }
    if(childrenLength != 2){
        print(ofThisObj.name + " has more/less than 2 children. please double check your tree structure in the hierarchy.")
        return null; //if we don't have exactly 2 options, there is an issue with the tree
    }
    return true;  // if there are 2 children / options, continue with the quizz
}




/*
We call "onLeft" and "onRight" through the "tilt Head" script, but you can call these functions from 
anywhere you'd like. ( with a tap on the left/right half of the screen for example )
It checks if input is currently allowed. If yes, it animates the Mask accordingly and 
adds either a "0" ( =left ) or a "1" ( = right) to the choicesPath.
*/
//@ui {"widget":"label"}
//@input SceneObject maskTweenObj {"hint":"Has a tween script component that animates the mask"}
script.api.onLeft = function(){
    if(!inputAllowed) return;
    choicesPath = choicesPath + 0;
    global.tweenManager.startTween( script.maskTweenObj, "moveRight");
    registerChoice(0);
    
}
script.api.onRight = function(){
    if(!inputAllowed) return;
    choicesPath = choicesPath + 1; 
    global.tweenManager.startTween( script.maskTweenObj, "moveLeft");
    registerChoice(1);
}

function registerChoice(choiceIndex){
    inputAllowed = false;
    currentRoot = currentRoot.getChild(choiceIndex); // sets the new root for the next question
    
    // mask animation plays before we progress with the quizz and reset the mask bounds
    var waitForTweenToBeFinished = script.createEvent("DelayedCallbackEvent");
    waitForTweenToBeFinished.bind(function (eventData) {
        inputAllowed = true;
        progressQuizz(currentRoot);
    });
    waitForTweenToBeFinished.reset(1);
    print(choicesPath);
}




/*
if there are no more choices found in the tree, we deactivate the Quizz UI and enable the UI for the result screen.
We also send out a trigger to set the texture + result text through behaviour scripts.
You can also take a look at the "Results Script" on the "Quizz Results" Object to manage your results more easily.
*/
//@ui {"widget":"label"}
//@input SceneObject resultImg {"label":"Final Image"}
//@input SceneObject resultText {"label":"Final Text"}
//@input SceneObject restartHint 
function triggerEndResult(){
    script.leftChoiceText.getSceneObject().enabled = false;
    script.rightChoiceText.getSceneObject().enabled = false;
    script.resultImg.enabled = true;
    script.resultText.enabled = true;
    script.restartHint.enabled = true;
    global.behaviorSystem.sendCustomTrigger(choicesPath);
    
    //enable this to use the "Results Controller Example" script
    // global.setResultsTo(choicesPath) 
}





/*
When the "tap to restart" hint is shown, we can tap the screen to reset all the variables,
deactivate the result screen UI and enable the quizz UI again.
Then we check for children/options again in the original "root" object of the tree.
*/
script.restartQuizz = function(){
    if(!script.restartHint.enabled) return;
    
    currentRoot = root;
    script.resultImg.enabled = false;
    choicesPath = "";
    script.leftChoiceText.getSceneObject().enabled = true;
    script.rightChoiceText.getSceneObject().enabled = true;
    script.resultText.enabled = false;
    inputAllowed = true;
    script.restartHint.enabled = false;
    progressQuizz(root);
}