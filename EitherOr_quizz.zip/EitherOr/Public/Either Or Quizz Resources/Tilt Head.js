//@input Component.Head head 
//@input float angle {"widget" : "slider", "min" : 0, "max" : 90, "step" : 0.1}

//@input bool callApiFunc
//@input Component.ScriptComponent scriptWithApi  {"showIf" : "callApiFunc"}
//@input string onLeftFunction = "onLeft" {"showIf" : "callApiFunc"}
//@input string onRightFunction = "onRight"  {"showIf" : "callApiFunc"}

if (!script.head) {
    print("Warning, please set head input. You can add Head Binding to teh scene by clicking on the + Button in the Objects panel");
}
script.threshold = Math.abs(Math.sin(script.angle / 180 * Math.PI))

var headTransform = script.head.getSceneObject().getTransform();
const eps = 0.1;
var State = { "NONE": 0, "LEFT": 1, "RIGHT": 2 };
var currentState = State.None;
var x;

script.createEvent("UpdateEvent").bind(onUpdate);

function onUpdate() {
    if (script.head.getFacesCount() > 0) {
        x = headTransform.up.x;
        if (Math.abs(x) < eps) {
            if (currentState != State.NONE) {
                currentState = State.NONE;
                // reset
            }
        } else if (x < -script.threshold) {
            if (currentState != State.LEFT) {
                currentState = State.LEFT;
                script.scriptWithApi.api[script.onLeftFunction]();
            }
        } else if (x > script.threshold) {
            if (currentState != State.RIGHT) {
                currentState = State.RIGHT;
                script.scriptWithApi.api[script.onRightFunction]();
            }
        }
    } else {
        if (currentState != State.NONE) {
            currentState = State.NONE;
        }
    }
}
