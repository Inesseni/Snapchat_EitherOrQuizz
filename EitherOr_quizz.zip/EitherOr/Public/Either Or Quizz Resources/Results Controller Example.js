// -----JS CODE-----
//@input Component.Text resultText
//@input Component.Image resultImage

//@input string[] resultTexts
//@input Asset.Texture[] resultTextures
var newResultText;
var newResultTexture;
global.setResultsTo = function(result){
    switch(result){
        case "000":
        newResultText = script.resultTexts[0];
        newResultTexture = script.resultTextures[0];
        break;
        case "001":
        newResultText = script.resultTexts[1];
        newResultTexture = script.resultTextures[1];
        break;
        /*
        case "01":
        newResultText = script.resultTexts[2];
        break;
        ...
        ...
        contine with as many results as you have
        */
        default :
        print("result not in the list yet");
        break;
    }
    
    script.resultText.text = newResultText;
    script.resultImage.mainPass.baseTex = newResultTexture;
}
